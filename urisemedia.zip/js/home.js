// Pre-loader

var loader = document.getElementById('loader');
console.log(loader);

function remove_loader() {
	loader.style.display = 'none';
}

// Landing page

var i = 1;
var image1 = document.getElementsByClassName('inside_landingimg1');
var image2 = document.getElementsByClassName('inside_landingimg2');
var image3 = document.getElementsByClassName('inside_landingimg3');
var info = [
			{
			banner: "An Eye for Detail",
			service: "Performance<br>Marketing",
			link: "performance_marketing.html",
			image1: "url('images/business1.png')",
			image2: "url('images/business2.png')",
			image3: "url('images/business3.png')",
			alphabet1: 'P',
			alphabet2: 'M'
			},

			{
			banner: "Keeping an Ear to the Ground",
			service: "Influencer<br>Marketing",
			link: "Influencer_marketing.html",
			image1: "url('images/pencil1.png')",
			image2: "url('images/pencil2.png')",
			image3: "url('images/pencil3.png')",
			alphabet1: 'I',
			alphabet2: 'M'
			},

			{
			banner: "A Knack for producing Tasteful Videos",
			service: "Video<br>Production",
			link: "video_production.html",
			image1: "url('images/book1.png')",
			image2: "url('images/book2.png')",
			image3: "url('images/book3.png')",
			alphabet1: 'V',
			alphabet2: 'P'
			}
];

image1[0].classList.add('startanimation1');
image2[0].classList.add('startanimation2');
image3[0].classList.add('startanimation3');
setTimeout(removestartanime1,1000);
setTimeout(removestartanime2,1500);
setTimeout(removestartanime3,1400);



//For beginning transition 
function removestartanime1(){
	image1[0].classList.remove('startanimation1');
}
function removestartanime2(){
	image2[0].classList.remove('startanimation2');
}

function removestartanime3(){
	image3[0].classList.remove('startanimation3');
}


// For each transition
function removeanime1(){
	image1[0].classList.remove('animation1');
}

function removeanime2(){
	image2[0].classList.remove('animation2');
}

function removeanime3(){
	image3[0].classList.remove('animation3');
}



//trigger animation button 
var trigger_section_change = document.getElementsByClassName('transition_button');
trigger_section_change[0].addEventListener('click',button_click);

function button_click() {

	var indicator = document.getElementsByClassName('circle');
	var banner = document.getElementsByClassName('banner');
	var service_name = document.getElementsByClassName('service_name');
	var service_link = document.getElementsByClassName('service_link');
	var alpha1 = document.getElementsByClassName('alpha1');
	var alpha2 = document.getElementsByClassName('alpha2');
	var text_section = document.getElementsByClassName('landing_sec_2');

	image1[0].classList.add('animation1');
	image2[0].classList.add('animation2');
	image3[0].classList.add('animation3');

	text_section[0].classList.add('text_animation');
	setTimeout(removetextanime,1000);

	function removetextanime() {
	text_section[0].classList.remove('text_animation');

	setTimeout(removeanime1,1000);
	setTimeout(removeanime2,1100);
	setTimeout(removeanime3,1300);

	if(i==1) {
		indicator[0].style.backgroundColor = 'transparent';
		indicator[1].style.backgroundColor = '#048ba8';
		indicator[2].style.backgroundColor = 'transparent';
		alpha1[0].innerHTML = info[1].alphabet1;
		alpha2[0].innerHTML = info[1].alphabet2;
		setTimeout(picchange11,500);
		setTimeout(picchange12,600);
		setTimeout(picchange13,800);

		function picchange11() {
			image1[0].style.backgroundImage= info[1].image1;
		}

		function picchange12() {
			image2[0].style.backgroundImage= info[1].image2;
		}

		function picchange13() {
			image3[0].style.backgroundImage= info[1].image3;
		}		

		setTimeout(text_animate,500);

		function text_animate() {
		banner[0].innerHTML = info[1].banner;
		service_name[0].innerHTML = info[1].service;
		service_link[0].href = info[1].link;
		}

		i++;
	}

	else if(i==2) {
		indicator[0].style.backgroundColor = 'transparent';
		indicator[1].style.backgroundColor = 'transparent';
		indicator[2].style.backgroundColor = '#048ba8';
		alpha1[0].innerHTML = info[2].alphabet1;
		alpha2[0].innerHTML = info[2].alphabet2;
		setTimeout(picchange21,500);
		setTimeout(picchange22,600);
		setTimeout(picchange23,800);

		function picchange21() {
			image1[0].style.backgroundImage= info[2].image1;
		};

		function picchange22() {
			image2[0].style.backgroundImage= info[2].image2;
		};

		function picchange23() {
			image3[0].style.backgroundImage= info[2].image3;
		};		

		setTimeout(text_animate,500);

		function text_animate() {
		banner[0].innerHTML = info[2].banner;
		service_name[0].innerHTML = info[2].service;
		service_link[0].href = info[2].link;
		}
		i=0;
	}

	else {
		indicator[0].style.backgroundColor = '#048ba8';
		indicator[1].style.backgroundColor = 'transparent';
		indicator[2].style.backgroundColor = 'transparent';

		image1[0].style.backgroundImage = info[0].image1;
		image2[0].style.backgroundImage = info[0].image2;
		image3[0].style.backgroundImage = info[0].image3;
		alpha1[0].innerHTML = info[0].alphabet1;
		alpha2[0].innerHTML = info[0].alphabet2;
		setTimeout(picchange01,200);
		setTimeout(picchange02,700);
		setTimeout(picchange03,800);

		function picchange01() {
			image1[0].style.backgroundImage= info[0].image1;
		};

		function picchange02() {
			image2[0].style.backgroundImage= info[0].image2;
		};

		function picchange03() {
			image3[0].style.backgroundImage= info[0].image3;
		};	


		setTimeout(text_animate,500);

		function text_animate() {
		banner[0].innerHTML = info[0].banner;
		service_name[0].innerHTML = info[0].service;
		service_link[0].href = info[0].link;
		}
		i++;
	}

}
}


// Text Appear Animation
window.addEventListener("scroll", scrollmove);

function scrollmove() {
	var text_appear = document.getElementsByClassName("content1");
	var introposition = text_appear[0].getBoundingClientRect().top;
	console.log(introposition);
	var screenposition = window.innerHeight;
	console.log(screenposition);

	if(introposition<screenposition/1.4)
	{
		text_appear[0].classList.add('intro-appear');
	}
}


// Objects move parallax 
function parallax() {
    var s = document.getElementsByClassName("multiuse_circle");
  var yPos = 0-window.pageYOffset/50;  
  s[0].style.top = yPos + "%"; }

window.addEventListener("scroll", function(){
    parallax(); 
});